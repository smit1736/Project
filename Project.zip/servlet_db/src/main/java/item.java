import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/item")
public class item extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public item() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter p = response.getWriter();

		String action = request.getParameter("action");

		try {
			String db = "com.mysql.jdbc.Driver";
			String db1 = "jdbc:mysql://localhost:3306/electronics_shop";
			Class.forName(db);
			Connection c = DriverManager.getConnection(db1, "root", "");

			switch (action) {
				case "insert":
					int id = Integer.parseInt(request.getParameter("id"));
					String itemName = request.getParameter("i_name");
					String itemCategories = request.getParameter("i_categories");
					int itemPrice = Integer.parseInt(request.getParameter("i_price"));

					PreparedStatement insertStmt = c.prepareStatement("INSERT INTO item VALUES (?, ?, ?, ?)");
					insertStmt.setInt(1, id);
					insertStmt.setString(2, itemName);
					insertStmt.setString(3, itemCategories);
					insertStmt.setInt(4, itemPrice);
					insertStmt.executeUpdate();
					p.println("<script>alert('Record inserted successfully!'); window.location.href = 'item.html';</script>");
					break;

				case "update":
					int updateId = Integer.parseInt(request.getParameter("id"));
					String newItemName = request.getParameter("i_name");
					String newItemCategories = request.getParameter("i_categories");
					int newItemPrice = Integer.parseInt(request.getParameter("i_price"));

					PreparedStatement updateStmt = c.prepareStatement(
							"UPDATE item SET i_name = ?, i_categories = ?, i_price = ? WHERE id = ?");
					updateStmt.setString(1, newItemName);
					updateStmt.setString(2, newItemCategories);
					updateStmt.setInt(3, newItemPrice);
					updateStmt.setInt(4, updateId);
					updateStmt.executeUpdate();
					p.println("<script>alert('Record updated successfully!'); window.location.href = 'item.html';</script>");
					break;

				case "select":
					int selectId = Integer.parseInt(request.getParameter("id"));

					PreparedStatement selectStmt = c.prepareStatement("SELECT * FROM item WHERE id = ?");
					selectStmt.setInt(1, selectId);
					ResultSet rs = selectStmt.executeQuery();

					p.println("<html><head>");
					p.println("<style>");
					p.println("body {");
					p.println("    font-family: Arial, sans-serif;");
					p.println("    background-color: #f4f4f9;");
					p.println("    margin: 0;");
					p.println("    padding: 20px;");
					p.println("    display: flex;");
					p.println("    justify-content: center;");
					p.println("    align-items: center;");
					p.println("    flex-direction: column;");
					p.println("}");
					p.println("h2 {");
					p.println("    color: #333;");
					p.println("    text-align: center;");
					p.println("}");
					p.println("table {");
					p.println("    width: 80%;");
					p.println("    border-collapse: collapse;");
					p.println("    margin: 20px 0;");
					p.println("    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);");
					p.println("}");
					p.println("th, td {");
					p.println("    padding: 12px;");
					p.println("    text-align: left;");
					p.println("    border-bottom: 1px solid #ddd;");
					p.println("}");
					p.println("th {");
					p.println("    background-color: #007bff;");
					p.println("    color: white;");
					p.println("}");
					p.println("tr:hover {");
					p.println("    background-color: #f1f1f1;");
					p.println("}");
					p.println("button {");
					p.println("    background-color: #007bff;");
					p.println("    color: white;");
					p.println("    border: none;");
					p.println("    padding: 10px 20px;");
					p.println("    cursor: pointer;");
					p.println("    border-radius: 5px;");
					p.println("    font-size: 16px;");
					p.println("    margin-top: 20px;");
					p.println("}");
					p.println("button:hover {");
					p.println("    background-color: #0056b3;");
					p.println("}");
					p.println("</style>");
					p.println("</head><body>");
					p.println("<h2>Selected Item Details</h2>");

					if (rs.next()) {
					    p.println("<table>");
					    p.println("<tr><th>Item ID</th><th>Item Name</th><th>Item Categories</th><th>Item Price</th></tr>");
					    p.println("<tr>");
					    p.println("<td>" + rs.getInt(1) + "</td>");
					    p.println("<td>" + rs.getString(2) + "</td>");
					    p.println("<td>" + rs.getString(3) + "</td>");
					    p.println("<td>" + rs.getInt(4) + "</td>");
					    p.println("</tr>");
					    p.println("</table>");
					} else {
					    p.println("<p>No item found with ID: " + selectId + "</p>");
					}

					// Add Back button
					p.println("<br><button onclick=\"location.href='item.html'\">Back</button>");
					p.println("</body></html>");

					break;

				case "delete":
					int deleteId = Integer.parseInt(request.getParameter("id"));

					PreparedStatement deleteStmt = c.prepareStatement("DELETE FROM item WHERE id = ?");
					deleteStmt.setInt(1, deleteId);
					deleteStmt.executeUpdate();
					p.println("<script>alert('Record deleted successfully!'); window.location.href = 'item.html';</script>");
					break;

				default:
					p.println("Invalid action!");
			}
			c.close();
		} catch (Exception e) {
			p.print(e.getMessage());
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}
